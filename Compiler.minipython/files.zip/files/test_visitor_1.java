String str = "asdf"
int x = 5
System.out.println(str+x);
