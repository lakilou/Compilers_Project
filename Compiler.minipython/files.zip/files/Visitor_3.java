import minipython.analysis.DepthFirstAdapter;
import minipython.node.*;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;

public class Visitor_3 extends DepthFirstAdapter {

    private Hashtable symbolTable;

    Visitor_3(Hashtable symbolTable) {
        this.symbolTable = symbolTable;
    }

    @Override
    public void inALessComparison(ALessComparison node) {
        PExpression expr1 = node.getExpr1();
        PExpression expr2 = node.getExpr2();

        
    }
}