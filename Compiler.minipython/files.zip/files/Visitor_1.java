import minipython.analysis.DepthFirstAdapter;
import minipython.node.*;
import java.util.Hashtable;
// Function Definition
public class Visitor_1 extends DepthFirstAdapter {

    private Hashtable symbolTable;

    Visitor_1(Hashtable symbolTable) {
        this.symbolTable = symbolTable;
    }

    @Override
    public void inAFunction(AFunction node) {
        String functionName = ((AFuncName)node.getFuncName()).getIdentifier().toString();
        int line = ((AFuncName)node.getFuncName()).getIdentifier().getLine();
        int position = ((AFuncName)node.getFuncName()).getIdentifier().getPos();
        if (symbolTable.containsKey(functionName)) {
            System.out.println("Error: [" + line + "/" + position + "] - " + functionName + " is already defined.");
        }
        else {
            symbolTable.put(functionName, node);
        }
    }

}
