x = asdf()

def asdf():
	print 5
