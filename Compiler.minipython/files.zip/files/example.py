import math.addition as add, math.subtraction as minus
from math import addition as add, subtraction as minus

def printAllElements(list):
	for element in list:
		print element


numbers = [10, 20, 30, 40]
printAllElements(numbers)

greaterThan25 = 0
while not x<x and true:
	if max(list.removeLast()) != 25:
		greaterThan25 += 1

addItem(numbers, greatThan25 + (5 + 4) * 2**4 / 2)

assertion = "Hello World"

assert a
assert a, b+3

some = 100 + obj.asdf(2, x)

x = open("dir",'h')y = type(d)print max(3, 4, 7)print min(2, 4)

if x > y :
print "hello", 3if x < y :
print "hello", 3if x != y :
print "hello", 3if x == y :
print "hello", 3if true:
print "da"if false:
print "no"

while x < y or not z >= k:
print "hello", 3while x > y :
print "hello", 3while x < y :
print "hello", 3while x != y :
print "hello", 3while x == y :
print "hello", 3
while x > y and x == z:
print "hello", 3
while x > y and x == z or x < z:
print "hello", 3

assert a
assert a, b+3


